declare module 'tailwindcss/lib/cli/build';
declare module '*?inline' {
  const src: string;
  export default src;
}
